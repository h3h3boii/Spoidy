module.exports = ({
	name: 'eval',
	code: `
$eval[$message]
$onlyForIDs[613963112726659092;Sorry but only the developer can use it.]`
});